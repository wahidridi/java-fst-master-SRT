package encapsulation_2;

public class Amar {
private int num = 10;

public int getNum() {
	return num;
}

public void setNum(int num) {
	this.num = num;
}






}
