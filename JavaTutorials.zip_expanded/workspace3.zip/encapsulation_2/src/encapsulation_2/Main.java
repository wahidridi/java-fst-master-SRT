package encapsulation_2;

public class Main {

	public static void main(String[] args) {
		
		Amar a = new Amar();
	
		System.out.println(a.getNum());
a.setNum(20);
System.out.println(a.getNum());



	}

}
