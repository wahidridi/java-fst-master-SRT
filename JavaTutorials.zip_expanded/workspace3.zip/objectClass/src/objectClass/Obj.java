package objectClass;

public class Obj {

	public static void main(String[] args) {

		Main m = new Main(10);
		Main m2 = new Main(10);
        
		System.out.println(m.equals(m2));
		System.out.println(m.hashCode());
		System.out.println(m.toString());
	}

}
