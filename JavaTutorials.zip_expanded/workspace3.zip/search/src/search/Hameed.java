package search;

import java.util.ArrayList;
import java.util.Scanner;

public class Hameed {

	public static void main(String[] args) {
		ArrayList<String> abcd = new ArrayList<String>();

		  abcd.add("muhammed");
		  abcd.add("essa");
		  abcd.add("hameed");
		  abcd.add("yousuf");
		  abcd.add("omer");
		 
		  System.out.print("Please enter a name: ");
		  Scanner input = new Scanner(System.in);
		 String name = input.nextLine();
		input.close();
		 
for (int i = 0; i < abcd.size();) {
	if(abcd.contains(name) ){
	System.out.println(name);
	break;
}else{
	System.out.println("This name : ("+name+") not in DB");
	break;
}
	}

	}

}
