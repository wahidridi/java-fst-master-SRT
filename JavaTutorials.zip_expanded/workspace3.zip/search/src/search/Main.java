package search;

import java.util.ArrayList;


public class Main {

	public static void main(String[] args) {
		ArrayList<String> abc = new ArrayList<String>();

		  abc.add("muhammed");
		  abc.add("essa");
		  abc.add("hameed");
		  abc.add("yousuf");
		  abc.add("omer");
		  
		 String name = "omer";
for (int i = 0; i < abc.size();) {
	if(abc.contains(name) ){
	System.out.println(name);
	break;
}else{
	System.out.println("This name : ("+name+") not in DB");
	break;
}
	}
		 
			

	}

}
