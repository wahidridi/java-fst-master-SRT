
public class Main {

	public static void main(String[] args) {
		
         int number = 5 ;
         
         if (number >=1 && number <=5) {
			System.out.println("yes number = 5");
		}

         else {
        	 System.out.println("you are out of range");
         }

	}

}
