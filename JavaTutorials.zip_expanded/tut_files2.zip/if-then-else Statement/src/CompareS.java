
public class CompareS {

	public static void main(String[] args) {
		

		String name = "Muhammed";
		String name2 = new String("Muhammed");
		
		if (name2.equals("Muhammed") ) {
			System.out.println("Yes ");
		}
		else {
			System.out.println("No ");
		}
	}

}
