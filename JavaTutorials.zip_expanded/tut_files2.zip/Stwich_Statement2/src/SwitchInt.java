
public class SwitchInt {

	public static void main(String[] args) {
		
		int number = 2 ;
		
		switch (number) {
		case 1:
			System.out.println(" This is No. 1");
		break;
		case 2:
			System.out.println(" This is No. 2");
		break;
		case 3:
			System.out.println(" This is No. 3");
			break;
		default:
			System.out.println(" This is greater than 1,2,3");
		break;
		}
 
         


	}

}
