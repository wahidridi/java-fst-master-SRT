
public class Switch_String {

	public static void main(String[] args) {
		

		String value = "Essa";
		switch (value) {
		case "Muhammed":
			System.out.println("Muhammed");
			break;
		case "Essa":
			System.out.println("Essa");
			break;
		case "Hameed":
			System.out.println("Hameed");
			break;
		default:
			break;
		}

	}

}
