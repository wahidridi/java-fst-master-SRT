
public enum Names {
	
	MUHAMMED , ESSA , HAMEED ;

}
