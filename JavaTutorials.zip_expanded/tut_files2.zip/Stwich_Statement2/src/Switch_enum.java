
public class Switch_enum {

	public static void main(String[] args) {
// int number = 2 ;
		
		Names name = Names.ESSA;
		
		switch (name) {
		case MUHAMMED:
			System.out.println(" Muhammed");
		break;
		case ESSA:
			System.out.println(" Essa");
		break;
		case HAMEED:
			System.out.println(" Hameed");
			break;
		default:
			System.out.println("No value");
		break;
		}

	}

}
