package instance_methods;

public class instance_int {

	public static void main(String[] args) {
	
		Hayder m = new Hayder();
		m.i=10;
		m.essa();
		 System.out.println(m.i);
		

			}
		}
class Hayder{
	     int i =6 ;
	      public   void essa(){
	    	  System.out.println("Muhammed Essa");
	    	  System.out.println(i);
	      }
}



