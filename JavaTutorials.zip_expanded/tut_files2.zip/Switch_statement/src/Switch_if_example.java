
public class Switch_if_example {

	public static void main(String[] args) {
		  String color = "red";  
	      
		    if (color.equals("red")) {  
		      System.out.println("Color is Red");  
		    } else if (color.equals("green")) {  
		      System.out.println("Color is Green");  
		    } else {  
		      System.out.println("Color not found");  
		    }  

	}

}
