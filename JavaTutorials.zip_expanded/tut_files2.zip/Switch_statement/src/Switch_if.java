
public class Switch_if {

	 public static void main(String[] args) {
	int month = 2;
	if (month == 1) {
	    System.out.println("January");
	} else if (month == 2) {
	    System.out.println("February");
	}
}
}
