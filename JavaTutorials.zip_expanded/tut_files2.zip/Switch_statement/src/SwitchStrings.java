
public class SwitchStrings {
	public static void main(String[] args) {
	String color = "red";  
	   
	 switch (color) {  
	 case "red":  
	   System.out.println("Color is Red");  
	   break;  
	case "green":  
	  System.out.println("Color is Green");  
	   break;  
	 default:  
	     System.out.println("Color not found");  
	 }  
}
}