
public class Main {

	public static void main(String[] args) {
		
		//System.out.println("Muhammed  Essa ");
		//System.out.println("Muhammed \" Essa\"");
		//System.out.println("Muhammed \' Essa\'");
		//System.out.println("Muhammed \t Essa");
		
		//System.out.println("Muhammed \n Essa");
		//System.out.println("Muhammed \f Essa");
		System.out.println("Muhammed \\ Essa");
	}

}
