package constructorMethods;

public class Main {

	public static void main(String[] args) {


Muhammed name = new Muhammed(30,"Muhammed");
Muhammed name2 = new Muhammed(29,"Ali");

name.show();
name2.show();
System.out.println("-----------------------");
Essa ess1 = new Essa("Muhammed","Essa");
Essa ess2 = new Essa("Muhammed","Essa",30);

ess1.show2();
ess2.show();

	}

}
