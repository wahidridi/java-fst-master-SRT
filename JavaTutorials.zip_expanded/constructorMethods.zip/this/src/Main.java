
public class Main {

	public static void main(String[] args) {

Essa essa = new Essa(29,"Ali");
Essa essa2 = new Essa(29,"Ahmed");

essa.show();
essa2.show();


	}

}
