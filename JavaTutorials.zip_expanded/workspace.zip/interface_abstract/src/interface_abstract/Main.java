package interface_abstract;

public class Main {

	public static void main(String[] args) {
		
		Muhammed h = new Hameed();

		h.back();
		h.mute();
		h.next();
		h.play();
		h.show();
	}

}
