package interface2;


class Yousuf implements Hassan,Omer{
	public void see(){
		System.out.println("Muhammed Essa");
	}
}

public class Essa {

	public static void main(String[] args) {
		
		Yousuf y = new Yousuf();
		y.see();
	}

}
