package interface2;

public interface Hassan {

	public void see();
}
