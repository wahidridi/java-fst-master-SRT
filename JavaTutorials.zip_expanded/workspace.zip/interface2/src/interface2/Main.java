package interface2;

interface display1{
	public void see();
}
interface display2{
	public void see2();
}

class Muhammed implements display1,display2{
	@Override
	public void see2() {
		System.out.println("display2");
		
	}
	@Override
	public void see() {
		System.out.println("display1");
	}
	
}

public class Main {

	public static void main(String[] args) {
		Muhammed muh = new Muhammed();
		muh.see();
		muh.see2();

	}

}
