package interface2;

public interface Omer {
	public void see();
}
