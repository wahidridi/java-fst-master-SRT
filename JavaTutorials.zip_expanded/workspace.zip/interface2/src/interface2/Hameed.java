package interface2;

interface display3{
	public void see();
}
interface display4 extends display3{
	public void see2();
}
class Muhamm implements display4{

	@Override
	public void see() {
		System.out.println("Muhammed Essa");
		
	}

	@Override
	public void see2() {
		System.out.println("Muhammed Essa2");
		
	}


	}

public class Hameed {

	public static void main(String[] args) {
		
		Muhamm m = new Muhamm();
		m.see();
		m.see2();

	}

}
