package com.sami;

import com.samir.Samir;

public class Main extends Samir{

	public static void main(String[] args) {
		
		Main s = new Main();
		s.see();
		

	}

}
