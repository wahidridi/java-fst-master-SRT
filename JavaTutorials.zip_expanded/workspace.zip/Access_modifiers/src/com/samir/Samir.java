package com.samir;

public class Samir {

	protected void see(){
		System.out.println("Muhammed Essa");
		
	}
}
