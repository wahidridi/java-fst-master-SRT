package com.usama;

import com.walid.Walid;

public class Usama {

	public static void main(String[] args) {
		
		Walid a = new Walid();
		a.see();

	}

}
