package com.muhammed;
class Ahmed{
	
	private String name = "Muhammed";
	private void see(){
		System.out.println("Muhammed Essa");
	}	
}

public class Essa {

	public static void main(String[] args) {
		
		Ahmed m = new Ahmed();
		
		System.out.println(m.name);
		m.see();

	}

}
