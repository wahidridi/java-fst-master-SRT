package com.muhammed;


class Muhammed{
	
	private Muhammed(){
		System.out.println("Muhammed Essa");
	}
	 void name(){
		System.out.println("Muhammed Essa");
	}	
}


public class Main {

	public static void main(String[] args) {
		
		Muhammed m = new Muhammed();
		
	
		m.name();
	}

}
