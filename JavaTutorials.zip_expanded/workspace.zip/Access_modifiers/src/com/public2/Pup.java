package com.public2;

public class Pup {

	public void see(){
		System.out.println("Muhammed Essa Hameed");
	}
}
