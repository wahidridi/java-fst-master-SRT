package com.walid;

 class Walid {

	
	public void see(){
		System.out.println("Muhammed Essa");	
		}
	}
	

