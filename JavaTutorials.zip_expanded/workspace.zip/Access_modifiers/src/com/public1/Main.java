package com.public1;

import com.public2.Pup;

public class Main extends Pup{

	public static void main(String[] args) {
		
		Pup p = new Pup();
		p.see();

	}

}
