package com.muhammed.calc.math;
import java.util.Scanner;

/**
 * this class for Math operator
 *
 */
public class MathOper {
	private static Scanner in3;
	private static Scanner in4;
	private static Scanner in2;

	/**
	 *  select Operator Add , sub ,multi ,Div
	 */

	public static int operatorSelect() {
		in2 = new Scanner(System.in);
		System.out.print("1:Add ,2:sub ,3:Mult ,4:Div :");
		int num = in2.nextInt();
		return num;
		
	}
	
	/**
	 * This is : <b>Div operator</b> method
	 */
	public static void addDiv() {
		
		Scanner in = new Scanner(System.in);
		System.out.print("Enter the First No :");
		double d1 = in.nextDouble();
		System.out.print("Enter the Second No :");
		double d2 = in.nextDouble();
		double result = d1 / d2 ;
		System.out.println(result);
		in.close();
		
	}

	
	/**
	 *  Multi operator
	 */
	public static void addMult() {
		in3 = new Scanner(System.in);
		System.out.print("Enter the First No :");
		double d1 = in3.nextDouble();
		System.out.print("Enter the Second No :");
		double d2 = in3.nextDouble();
		double result = d1 * d2 ;
		System.out.println(result);
		
	}


	/**
	 *  Sub operator
	 */
	public static void addSub() {
		in4 = new Scanner(System.in);
		System.out.print("Enter the First No :");
		double d1 = in4.nextDouble();
		System.out.print("Enter the Second No :");
		double d2 = in4.nextDouble();
		double result = d1 - d2 ;
		System.out.println(result);
		
	}

	/**
	 *  add operator
	 */
	public static void addValue() {
		Scanner in5 = new Scanner(System.in);
		System.out.print("Enter the First No :");
		double d1 = in5.nextDouble();
		System.out.print("Enter the Second No :");
		double d2 = in5.nextDouble();
		double result = d1 + d2 ;
		System.out.println(result);
		in5.close();
	}
}
