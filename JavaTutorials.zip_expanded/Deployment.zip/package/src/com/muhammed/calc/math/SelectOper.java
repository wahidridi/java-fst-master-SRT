package com.muhammed.calc.math;
/**
 * this class 	for select operator.
 *
 */
public class SelectOper {

	public static void operators(int num) {
		switch (num) {
		case 1:
			MathOper.addValue();
			break;
		case 2:
			MathOper.addSub();
			break;
		case 3:
			MathOper.addMult();
			break;
		case 4:
			MathOper.addDiv();
			break;
		default:
			break;
		}
	}
}
