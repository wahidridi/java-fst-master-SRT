package com.muhammed.clac;

import com.muhammed.calc.math.MathOper;
import com.muhammed.calc.math.SelectOper;

/**
 * @author muhammed
 *@version 1.0
 */
public class Main {

	/**
	 * Math Operator
	 */
	public static void main(String[] args) {
		int num = MathOper.operatorSelect();
		SelectOper.operators(num);				

	}
}
