package encapsulation;

public class Info {
	public static void main(String[] args){  
		Employee s=new Employee();  
		s.setName("Muhammed");  
		System.out.println(s.getName());  
		}  
		}  


