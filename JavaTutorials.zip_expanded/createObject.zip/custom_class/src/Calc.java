public class Calc {


	public static void main(String[] args) {

		
			int num = MathOper.operatorSelect();
			SelectOper.operators(num);
					
		}

}
	


