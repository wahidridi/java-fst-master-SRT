package com.muhammed.clac;
import com.muhammed.calc.math.MathOper;
import com.muhammed.calc.math.SelectOper;



public class Clac {

	public static void main(String[] args) {
		int num = MathOper.operatorSelect();
		SelectOper.operators(num);
				

	}

}
