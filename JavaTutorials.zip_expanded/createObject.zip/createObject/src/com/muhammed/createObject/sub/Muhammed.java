package com.muhammed.createObject.sub;

public class Muhammed {

public void muh(){
	System.out.println("Muhammed");
}

}
