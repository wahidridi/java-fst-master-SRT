package com.muhammed.createObject.sub;

public class Essa {

	public void myArray(Muhammed[] s){
		
		for (Muhammed muhammed : s) {
			muhammed.muh();
		}
		
	}

}

