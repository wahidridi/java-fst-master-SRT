package com.muhammed.private_public.private_public.pc;

public class Muhammed {

	private String name = "Muhammed";
	private String last_name = "Essa";
	private int age = 30;
	
	
	public void myName(){
		System.out.println(name+" "+last_name);
	}
	public void myage(){
		System.out.println("Age :"+age);
	}
}
