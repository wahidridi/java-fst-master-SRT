package com.muhammed.private_public.private_public.pc;

public class Essa {

	private String name ;
	private String last_name ;
	private int age ;
	
	public String myname(String s){
		name =s;
		return name;
	}
	public String mylast_name(String s1){
		last_name =s1;
		return last_name;
	}	
	public int age(int num){
		age =num;
		return age;
	}
	
}
