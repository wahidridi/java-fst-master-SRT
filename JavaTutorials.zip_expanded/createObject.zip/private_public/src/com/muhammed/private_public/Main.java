package com.muhammed.private_public;

import com.muhammed.private_public.private_public.pc.Essa;
import com.muhammed.private_public.private_public.pc.Muhammed;

public class Main {

	public static void main(String[] args) {
	
		Muhammed mu = new Muhammed();
		mu.myName();
		mu.myage();
	Essa ess = new Essa();
	System.out.println(ess.myname("Muhammed"));
	System.out.println(ess.mylast_name("Essa"));
	}

}
