import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException  {

FileReader in = null;
FileWriter out = null;
try{
in = new FileReader("muhammed.txt");
out = new FileWriter("copiedFile.txt");

int i;
while ((i = in.read()) != -1) {
	out.write(i);
	
}

}
finally {
	if(in !=null){
		in.close();
	}
	if(out !=null){
		out.close();
	}
	System.out.println("File copied !");
}
}
}

