package javaIO;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Main {

	public static void main(String[] args) {
	
		try {
			FileInputStream in = null;
			FileOutputStream out = null;
			
			in = new FileInputStream("testFile.txt");
			out = new FileOutputStream("newFile.txt");

			int i;
			while ((i = in.read()) !=-1) {
				out.write(i);
				
			}
			in.close();
			out.close();
			System.out.println("File copied !");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
}


}

