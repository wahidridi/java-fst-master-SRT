package clacculator;

import java.util.Scanner;

public class ScannerObj {

	 
	public static void main(String[] args) {
		
    Scanner in = new Scanner(System.in);
    System.out.print("Enter your name :");
    String s = in.nextLine();
     System.out.println(s);
     System.out.print("Enter your age :");
    int num = in.nextInt();
    System.out.println(num);
     in.close();


}
}