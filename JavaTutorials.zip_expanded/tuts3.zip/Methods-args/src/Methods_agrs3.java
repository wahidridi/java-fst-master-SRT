class Yusuf{
	public void Muham(String t ,String b){
		System.out.println(t + " " +b);
	}
	public void number(int age,int ag){
		System.out.println(age +ag);
	}
	public void numberString(String name,int salary){
		System.out.println(name +" , "+salary+"$");
	}
	public void Muhamm(String r){
		System.out.println(r );
	}
}
public class Methods_agrs3 {

	public static void main(String[] args) {

		result();
	}

	private static void result() {
		Yusuf essa = new Yusuf();
		essa.Muham("Muhammed Essa","AL- Timimy");
		essa.number(27,28);
		essa.numberString("Ali", 2000);
        String n = "Hello Java";
        essa.Muhamm(n);
	}

}
