class Muhammed{
	public void Muham(){
		System.out.println("Muhammed Essa");
	}
}

public class Methods_args {

	public static void main(String[] args) {

Muhammed essa = new Muhammed();
essa.Muham();

	}

}
