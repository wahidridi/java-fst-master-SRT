
public class Methods_agrs4 {

	public static void main(String[] args) {


	}

}
