import java.text.DateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateClass {

	public static void main(String[] args) {
		

		Date dt = new Date();
		System.out.println(dt);
		
		GregorianCalendar gc = new GregorianCalendar(2015, 4, 30);
		gc.add(GregorianCalendar.DATE, 1);
		
		Date dt2 = gc.getTime();
		
		DateFormat d1 = DateFormat.getDateInstance(DateFormat.FULL);
		String d2 = d1.format(dt2);
		System.out.println(d2);
		

	}

}
