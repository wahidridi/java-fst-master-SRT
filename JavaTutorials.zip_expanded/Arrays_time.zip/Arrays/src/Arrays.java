
public class Arrays {

	public static void main(String[] args) {
	
String [] s = new String [4];
  for (String string : s) {
	System.out.println(string);
}
  int [] num = new int [2];
for (int i = 0; i < num.length; i++) {
	System.out.println(num[i]);
}
double d[] = new double [4];
for (double dou : d) {
	System.out.println(dou);
}

String [] sTr ={"Muhammed","Essa","Hameed"};
for (String string : sTr) {
	System.out.println(string);
}
System.out.println("-----------------------------");
System.out.println(sTr[1]);
	}
	
}
