package time_runtime_error;

public class Time_runTime_Error {

	public static void main(String[] args) {
		



int [] num2 = {1,2,3};
System.out.println(num2[3]);

String name =null;
System.out.println(name);
int num = 9;
System.out.println(num);
		
	}

}
